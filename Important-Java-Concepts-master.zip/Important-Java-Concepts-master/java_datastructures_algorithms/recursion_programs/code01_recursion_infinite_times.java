// A method that calls itself is called recursive method.

public class RecursionExample1 {  
static void p(){  
System.out.println("hello");  
p();  
}  
  
public static void main(String[] args) {  
p();  
}  
}  