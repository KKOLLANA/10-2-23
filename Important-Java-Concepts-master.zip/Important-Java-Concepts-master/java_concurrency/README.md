# Some Concepts of Java
