package com.abc;  
/** 
This class is a user-defined class that contains one methods cube.
*/  
public class M{  
  
/** The cube method prints cube of the given number */  
public static void  cube(int n){System.out.println(n*n*n);}  
} 