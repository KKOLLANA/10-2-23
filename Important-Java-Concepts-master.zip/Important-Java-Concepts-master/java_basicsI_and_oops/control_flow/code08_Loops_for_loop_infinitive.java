public class ForExample {  
public static void main(String[] args) {  
    for(;;){  
        System.out.println("infinitive loop");  
    }  
}  
}  