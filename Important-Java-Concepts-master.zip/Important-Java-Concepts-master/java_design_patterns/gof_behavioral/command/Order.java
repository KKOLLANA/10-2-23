package java_design_patterns.gof_behavioral.command;

public interface Order {

    void execute();
}


