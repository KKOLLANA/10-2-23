package java_design_patterns.gof_creational.abstractfactory;

public interface Bank {
    String getBankName(String bank);
}
